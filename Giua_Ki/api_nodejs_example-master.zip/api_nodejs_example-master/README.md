# Api nodejs example
# Install package
Run `npm install`

# Run api
Run `npm run start`
